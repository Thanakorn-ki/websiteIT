A Pen created at CodePen.io. You can find this one at http://codepen.io/dan_reid/pen/rwhDf.

 Inspired by the loader found on http://www.polygon.com.
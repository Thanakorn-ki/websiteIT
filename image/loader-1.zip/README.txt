A Pen created at CodePen.io. You can find this one at http://codepen.io/samueljweb/pen/LbGxi.

 The first loader out of a series I'm going to be completing. You are free to use these as long as you keep the reference to me in the outputted CSS file! :-)
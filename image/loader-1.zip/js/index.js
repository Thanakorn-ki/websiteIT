// All loaders can be cloned/forked/downloaded here:
//
// https://github.com/Samlilli
//
// :-)